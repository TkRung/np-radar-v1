# NP Radar V1 — ชุดอัปเดตระดับน้ำ ThaiWater

จัดเตรียมวันที่ 4 ตุลาคม 2569 สำหรับ https://github.com/TkRung/np-radar-v1
Base commit: 0239efcbed84bb4ebe8153d44a1c601e0e2ca46e
Local update commit: 7af8af57a6ee2f23c7aee04fc8d77be352af41de

## สิ่งที่เพิ่ม
- มุมมองระดับน้ำตรวจวัดจาก ThaiWater แสดงสถานีบนแผนที่ สถานีใกล้ตำแหน่งที่เลือก เวลาและสถานะข้อมูล
- มุมมองพยากรณ์ระดับน้ำล่วงหน้าสูงสุด 72 ชั่วโมง เฉพาะสถานีที่ต้นทางมีแบบจำลองระดับน้ำหน่วยเมตร พร้อมกราฟและตาราง
- ระบุหน่วย ม.รทก. แยกข้อมูลตรวจวัดและแบบจำลอง และไม่แปลงค่าที่ขาดหายเป็นศูนย์
- การดึงข้อมูลฝั่งเซิร์ฟเวอร์สำหรับ Vercel และการอัปเดต service worker

## วิธีใช้ชุดอัปเดต
นี่คือชุดไฟล์ที่เปลี่ยนแปลง 11 ไฟล์สำหรับแอปเดิม ไม่ใช่แอปฉบับเต็ม
1. เริ่มจาก repository เดิมและตรวจว่า main ยังตรงกับ base commit ด้านบน หากมีการแก้ไขเพิ่มเติม ให้รวมการเปลี่ยนแปลงก่อนแทนไฟล์
2. สร้าง branch สำหรับอัปเดต แล้วคัดลอกไฟล์โค้ดทั้ง 11 ไฟล์ใน ZIP ลงที่ราก repository ตามโครงสร้างเดิม โดยแทนไฟล์ชื่อเดียวกัน เก็บไฟล์เดิมอื่น ๆ ไว้
3. ไม่ต้องอัปโหลด APPLY-UPDATE-TH.md หรือ changes.patch เข้าแอป ทั้งสองไฟล์เป็นเอกสารและทางเลือกสำหรับติดตั้ง
4. รัน npm test จากราก repository (ไม่ต้องติดตั้ง dependency เพิ่ม)
5. Commit และ push branch จากนั้นตรวจ deployment ของ Vercel ก่อนรวมเข้า main ตามขั้นตอนของโปรเจกต์
6. เปิดเว็บด้วย ?view=water เพื่อตรวจมุมมองใหม่ ตรวจปุ่มสลับเรดาร์/ระดับน้ำ แผนที่ GPS การเลือกสถานีพยากรณ์ และหน้าจอมือถือ

ทางเลือกสำหรับ Git: ใช้ changes.patch แทนการคัดลอกไฟล์ ห้ามใช้ทั้งสองวิธีซ้ำกัน

```sh
git switch -c feature/thaiwater-levels
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
npm test
git add README_TH.txt api/waterlevel.js index.html lib/water-data.js package.json sw.js tests/water-api.test.js tests/water-data.test.js vercel.json water-layer.js water.css
git commit -m "Add ThaiWater water levels and 72-hour forecasts"
```

## ผลตรวจสอบและสถานะ
- การทดสอบด้วย Node ผ่าน 11 กรณี ครอบคลุมการแปลงข้อมูล หน่วย เวลา ข้อมูลขาดหาย และ API
- การตรวจไวยากรณ์ JavaScript และ git diff --check ผ่าน
- ทดสอบ API จริงวันที่ 4 ตุลาคม 2569: observations ตอบ HTTP 200 และ 792 สถานี, models ตอบ HTTP 200 และ 63 สถานี, forecast ของสถานี 1132 ตอบ HTTP 200 และ 72 จุดรายชั่วโมง ตัวเลขนี้เป็นผล ณ เวลาทดสอบ
- ยังไม่ได้ตรวจหน้าจอจริงในเบราว์เซอร์: สภาพแวดล้อมตรวจสอบปิดกั้นการเปิด localhost
- ยังไม่ได้ส่งโค้ดเข้า GitHub หรือเผยแพร่เว็บ: การเชื่อมต่อ GitHub ตอบ 403 Resource not accessible by integration
- Codex Tasks ยังไม่มี environment ที่เชื่อมต่อในการตรวจครั้งนี้

## ความหมายของข้อมูล
แบบจำลองเป็นระดับน้ำ ณ สถานี ไม่ใช่ความลึกน้ำท่วมที่บ้านหรือทุกพิกัด บางสถานีอาจไม่มีข้อมูลครบ 72 ชั่วโมง ต้นทางไม่ส่งเวลารันแบบจำลอง จึงแสดงเวลาที่ดึงข้อมูลแยกต่างหาก เกณฑ์ข้อมูลตรวจวัดเก่าเกิน 3 ชั่วโมงเป็นเกณฑ์ของแอป ดูรายละเอียดแหล่งข้อมูลและการทำงานใน README_TH.txt

ไฟล์โค้ดในชุดอัปเดต:
- README_TH.txt
- api/waterlevel.js
- index.html
- lib/water-data.js
- package.json
- sw.js
- tests/water-api.test.js
- tests/water-data.test.js
- vercel.json
- water-layer.js
- water.css
